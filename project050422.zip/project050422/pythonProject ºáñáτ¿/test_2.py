import math

a = int(input("первая сторона "))
b = int(input("вторая сторона "))
c = (a + b) * 2
d = a * a + b * b

print("периметр {0}, длину диагонали. {1}"
.format(c, d))
