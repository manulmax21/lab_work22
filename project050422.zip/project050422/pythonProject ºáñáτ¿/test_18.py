import math

m = int(input("введите число "))
v = int(input("введите второе число "))
c = m/v
d = math.sqrt(a * b)

print("плотность материала этого тела {0}"
.format(c))