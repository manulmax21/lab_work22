import math

x = int(input("первое число "))
y = int(input("второе число "))
s = int(input("третье число "))

t = s / (x + y)


print("время автомобили встретятся ", t)
