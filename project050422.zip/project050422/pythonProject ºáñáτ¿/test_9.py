import math

a = int(input("Введите сторону "))
b = int(input("Введите сторону "))
c = int(input("Введите сторону "))
p = (a + b + c) / 2
s = math.sqrt(p * (p - a) * (p - b) * (p - c))
perimeter = a+b+c
print("Периметр треугольника ", perimeter)
print("Площадь треугольника равна ", s)