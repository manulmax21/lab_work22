import math

m = int(input("введите число "))
v = int(input("введите второе число "))
c = m/v
d = math.sqrt(a * b)

print("плотность населения в этом государстве {0}"
.format(c))