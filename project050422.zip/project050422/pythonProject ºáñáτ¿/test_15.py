import math

x = int(input("первое число "))
y = int(input("второе число "))
s = int(input("третье число "))
t = 30

s1 = s / (x + y)
s = s1 / t


print("расстояние будет между ними  ",
      s)