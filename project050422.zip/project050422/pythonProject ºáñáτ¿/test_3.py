import math

a = int(input("первое число "))
b = int(input("второе число "))
d = int(input("третье число "))
p = (a + b + d) / 2
c = math.sqrt(p*(p - a)*(p - b)*(p - d))
print("площадь треугольника по формуле Герона {0}"
.format(c))
