import math
from math import sqrt

a = int(input("первое число "))
b = int(input("второе число "))

alpha=int(input("Введите угол при большем основании в градусах: "))

alphar=alpha*math.pi/180
print("Площадь трапеции равна ",(a**2-b**2)/4*math.tan(alphar))