import math

m = int(input("введите число "))
v = int(input("введите второе число "))
if m!=v:
    if b%a:
        print(-b//a)
    else:
        print("NO")
    if b==0:
        print("inf")
else:
    print("NO")


