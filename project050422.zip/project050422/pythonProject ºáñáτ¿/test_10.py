from math import sqrt

print ('a = ')
a = float (input ())
print ('b = ')
b = float (input ())
print ('c = ')
c = float (input ())
print ('d = ')
d = float (input ())
s1 = a * b / 2
t = sqrt (a ** 2 + b ** 2)

p = (c + d + t) / 2

s2 = sqrt (p * (p - c) * (p - d) * (p - t))

s = s1 + s2

print ('Площадь заданного четырёхугольника:',
       '{0}'.format (s))