from math import sqrt

a = int(input("первое число "))
b = int(input("второе число "))
h = int(input("третье число "))


distance = h*(a+b)/2
print(distance)