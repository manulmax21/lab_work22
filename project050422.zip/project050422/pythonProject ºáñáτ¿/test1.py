import math

a = int(input("введите число "))
b = int(input("введите второе число "))
c = (a + b) / 2
d = math.sqrt(a * b)

print("среднее арифметическое {0}, геометрическое их модулей {1}"
.format(c, d))
