import math

r1 = int(input("введите число "))
r2 = int(input("введите второе число "))
c = math.pi * (r2 - r1)

print("площадь кольца {0}"
.format(c))