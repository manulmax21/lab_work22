import math

x = int(input("первое число "))
y = int(input("второе число "))

s = (x+y)/2
d = (x+y)/2-x
e = (x+y)/2-y


print("средний возраст ", s)
print("возраст тани отличается ", d)
print("возраст мити отличается ", e)