import math

a = int(input("стоимость 1 кг конфет "))
b = int(input("печенья "))
c = int(input("яблок "))

s =  ((a + b + c) * 1000) / 3


print("стоимость всей покупки ", s)