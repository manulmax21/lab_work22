import math

a = int(input("первое число "))
b = int(input("второе число "))
c = a + b
d = a - b
f = a * b
g = a // b

print("сумма {0}, разность {1}, произд. {2}, разн. {3}"
.format(c, d, f, g))
