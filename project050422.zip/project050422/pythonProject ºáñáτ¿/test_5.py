import math

a = int(input())
b = int(input())
c = int(input())

V = a * b * c
S = 2 * (a * b  +  b * c  +  a * c)

print("объем {0},  площадь боковой поверхности {1}"
.format(V, S))
