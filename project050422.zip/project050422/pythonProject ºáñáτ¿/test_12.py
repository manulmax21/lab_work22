import math

a = int(input("стоимость монитора "))
b = int(input("системного блока "))
c = int(input("клавиатуры "))
d = int(input("мыши "))

s =  ((a + b + c + d) *3) 


print("стоимость всей покупки ", s)