import math

x = int(input("первое число "))

s = x * 1.8 + 32
t = (x / 273) * -1

print("Фаренгейта; ", s)
print("Кельвина; ", t)