from math import sqrt

x1 = int(input("первое число "))
x2 = int(input("второе число "))
y1 = int(input("третье число "))
y2 = int(input("четвертое число "))

distance = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2))
print(distance)
