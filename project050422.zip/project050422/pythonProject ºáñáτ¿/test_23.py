import math

m = int(input("введите число "))
v = int(input("введите второе число "))
c = math.sqrt(m*m + v*v)
p = c + m + v
print("его периметр {0}"
.format(p))