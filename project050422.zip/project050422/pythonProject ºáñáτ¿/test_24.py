import math

a = int(input("введите число "))
b = int(input("введите второе число "))
h = int(input("введите третье число "))
d = (a - b) / 2
c = math.sqrt(h*h + d*d)
p = 2 * c + a + b
print("его периметр {0}"
.format(p))