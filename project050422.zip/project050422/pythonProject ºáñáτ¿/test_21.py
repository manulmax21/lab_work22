import math

m = int(input("введите число "))
v = int(input("введите второе число "))
c = math.sqrt(m*m + v*v)

print("его гипотенузa {0}"
.format(c))