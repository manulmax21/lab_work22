a = int(input("a "))
b = int(input("b "))

if a<9:
    print("None")
elif b>9:
    print("None")
else:
    c = int((a // 10) + (a % 10) + b)

print("сумма чисел равно: {0}".format(c))