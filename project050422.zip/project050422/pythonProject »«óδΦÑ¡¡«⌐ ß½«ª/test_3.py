
a1 = int(input("a1 "))
a2 = int(input("a2 "))
a3 = int(input("a3 "))
b1 = int(input("b1 "))
b2 = int(input("b2 "))




print((100*a3+10*a2+a1+(10*b2+b1)))