a = int(input("a "))
b = int(input("b "))


d1 = ((A % 10) + B) % 10;
d2 = (A/10) + ((A % 10) + B) / 10;

print("сумма чисел равно: {0}{1}".format(d1,d2))